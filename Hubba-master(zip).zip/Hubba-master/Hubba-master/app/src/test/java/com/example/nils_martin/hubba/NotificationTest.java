package com.example.nils_martin.hubba;

import org.junit.Test;

import static org.junit.Assert.*;

public class NotificationTest {

}