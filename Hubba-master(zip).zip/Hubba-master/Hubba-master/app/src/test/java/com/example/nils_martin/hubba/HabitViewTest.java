package com.example.nils_martin.hubba;

import com.example.nils_martin.hubba.ViewModel.HabitVM;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HabitViewTest {

    /*@Test
    public void testString(){
        String string = "MORNING";
        HabitVM habitView = new HabitVM();
        System.out.print(habitView.toLowerCase(string));
        assertEquals(habitView.toLowerCase(string), "Morning");
    }*/

}

