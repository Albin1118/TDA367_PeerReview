package com.example.nils_martin.hubba.Model;

public enum Frequency {

        DAILY,
        WEEKLY,
        MONTHLY

}
