package com.example.nils_martin.hubba.Model;

public interface IStreakAchievement {

    public Boolean assessAchievement();
}
