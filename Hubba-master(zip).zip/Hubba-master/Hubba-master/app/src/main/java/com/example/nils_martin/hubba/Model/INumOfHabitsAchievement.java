package com.example.nils_martin.hubba.Model;

public interface INumOfHabitsAchievement {

    public Boolean assessAchievement();
}
