package com.example.nils_martin.hubba.Model;

public enum Themes {
    ELITE,
    PINKFLUFFY,
    STANDARD
}
