package com.example.nils_martin.hubba.Model;

public interface Friend {

    String getUserName();

}
