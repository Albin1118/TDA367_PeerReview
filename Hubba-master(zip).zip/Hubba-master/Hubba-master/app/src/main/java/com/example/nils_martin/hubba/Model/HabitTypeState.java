package com.example.nils_martin.hubba.Model;

public interface HabitTypeState {
    public void updateHabit(Habit habit);
}
